const jwt = require('jsonwebtoken');
const SECRET = 'replace_this_with_env_secret';
function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: 'Missing auth' });
  const token = header.split(' ')[1];
  try {
    const payload = jwt.verify(token, SECRET);
    req.user = payload; next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}
module.exports = { authMiddleware, SECRET };