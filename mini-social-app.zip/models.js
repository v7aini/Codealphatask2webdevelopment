const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize({ dialect: 'sqlite', storage: './database.sqlite' });

const User = sequelize.define('User', {
  username: { type: DataTypes.STRING, unique: true, allowNull: false },
  passwordHash: { type: DataTypes.STRING, allowNull: false },
  bio: { type: DataTypes.TEXT }
});

const Post = sequelize.define('Post', { content: { type: DataTypes.TEXT, allowNull: false } });
const Comment = sequelize.define('Comment', { content: { type: DataTypes.TEXT, allowNull: false } });
const Follow = sequelize.define('Follow', {});
const Like = sequelize.define('Like', {});

User.hasMany(Post); Post.belongsTo(User);
Post.hasMany(Comment, { onDelete: 'CASCADE' }); Comment.belongsTo(Post);
Comment.belongsTo(User); User.hasMany(Comment);
User.belongsToMany(User, { as: 'Followers', through: Follow, foreignKey: 'followingId' });
User.belongsToMany(User, { as: 'Following', through: Follow, foreignKey: 'followerId' });
User.belongsToMany(Post, { through: Like, as: 'LikedPosts' }); Post.belongsToMany(User, { through: Like, as: 'Likers' });

module.exports = { sequelize, User, Post, Comment, Follow, Like };