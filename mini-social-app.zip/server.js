const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const { sequelize, User, Post, Comment, Follow, Like } = require('./models');
const { authMiddleware, SECRET } = require('./middleware');
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));
(async () => { await sequelize.sync(); console.log('DB synced'); })();

app.post('/api/register', async (req, res) => {
  const { username, password, bio } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'username/password required' });
  try {
    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({ username, passwordHash: hash, bio });
    const token = jwt.sign({ id: user.id, username: user.username }, SECRET);
    res.json({ token, user: { id: user.id, username: user.username, bio: user.bio } });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ where: { username } });
  if (!user) return res.status(400).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, username: user.username }, SECRET);
  res.json({ token, user: { id: user.id, username: user.username, bio: user.bio } });
});

app.get('/api/me', authMiddleware, async (req, res) => {
  const user = await User.findByPk(req.user.id, { attributes: ['id','username','bio'] });
  res.json({ user });
});

app.post('/api/posts', authMiddleware, async (req, res) => {
  const { content } = req.body;
  const post = await Post.create({ content, UserId: req.user.id });
  res.json(post);
});

app.get('/api/posts', authMiddleware, async (req, res) => {
  const posts = await Post.findAll({ order: [['createdAt','DESC']], include: [
    { model: User, attributes: ['id','username'] },
    { model: Comment, include: [{ model: User, attributes: ['id','username'] }] },
    { model: User, as: 'Likers', attributes: ['id'] }
  ] });
  const mapped = posts.map(p => ({
    id: p.id, content: p.content, createdAt: p.createdAt, user: p.User,
    comments: p.Comments.map(c => ({ id: c.id, content: c.content, user: c.User, createdAt: c.createdAt })),
    likes: p.Likers ? p.Likers.length : 0,
    likedByMe: p.Likers ? p.Likers.map(u => u.id).includes(req.user.id) : false
  }));
  res.json(mapped);
});

app.post('/api/posts/:id/comments', authMiddleware, async (req, res) => {
  const { content } = req.body;
  const comment = await Comment.create({ content, PostId: req.params.id, UserId: req.user.id });
  res.json(comment);
});

app.post('/api/posts/:id/like', authMiddleware, async (req, res) => {
  const post = await Post.findByPk(req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found' });
  const [like, created] = await Like.findOrCreate({ where: { UserId: req.user.id, PostId: req.params.id } });
  if (!created) { await like.destroy(); return res.json({ liked: false }); }
  res.json({ liked: true });
});

app.post('/api/users/:id/follow', authMiddleware, async (req, res) => {
  if (parseInt(req.params.id) === req.user.id) return res.status(400).json({ error: 'Cannot follow yourself' });
  const follow = await Follow.findOne({ where: { followerId: req.user.id, followingId: req.params.id } });
  if (follow) { await follow.destroy(); return res.json({ following: false }); }
  await Follow.create({ followerId: req.user.id, followingId: req.params.id });
  res.json({ following: true });
});

app.get('/api/users/:id', authMiddleware, async (req, res) => {
  const user = await User.findByPk(req.params.id, { attributes: ['id','username','bio'] });
  if (!user) return res.status(404).json({ error: 'User not found' });
  const followers = await Follow.count({ where: { followingId: user.id } });
  const following = await Follow.count({ where: { followerId: user.id } });
  const isFollowing = await Follow.findOne({ where: { followerId: req.user.id, followingId: user.id } });
  res.json({ user, followers, following, isFollowing: !!isFollowing });
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));